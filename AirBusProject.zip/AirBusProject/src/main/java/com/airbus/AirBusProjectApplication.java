package com.airbus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirBusProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirBusProjectApplication.class, args);
		System.out.println("Application started...");
	}

}
