package com.airbus.pojos;


import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the BUSROUTE database table.
 * 
 */
@Entity
@Table(name="busroute")
public class BusRoute  {

	@Id
	@GeneratedValue
	@Column(name="ROUTENO")
	private Integer routeNo;
	
	@Column(name="DESTINATION")
	private String destination;

	@Column(name="DISTANCE")
	private Integer distance;

	@Column(name="ENDTIME")
	private String endTime;

	@Column(name="FACILITY")
	private String facility;

	@Column(name="FARE")
	private Integer fare;

	@Column(name="SOURCE")
	private String source;

	@Column(name="STARTTIME")
	private String startTime;

	/*//bi-directional many-to-one association to Buses
	@ManyToOne
	@JoinColumn(name="BUSNUMBER")
	private Buses bus;
*/
	//bi-directional many-to-one association to Reservation
	@OneToMany(mappedBy="busroute", fetch=FetchType.EAGER)
	private Set<Reservation> reservations;

	public BusRoute() {
		System.out.println("BusRoute called");
	}

	public Integer getRouteNo() {
		return routeNo;
	}

	public void setRouteNo(Integer routeNo) {
		this.routeNo = routeNo;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public Integer getFare() {
		return fare;
	}

	public void setFare(Integer fare) {
		this.fare = fare;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public Set<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(Set<Reservation> reservations) {
		this.reservations = reservations;
	}

}