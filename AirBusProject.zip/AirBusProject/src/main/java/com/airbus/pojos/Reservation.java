package com.airbus.pojos;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="reservation")
public class Reservation {
	@Id
	@GeneratedValue//it is to generate the primary key value automatically
	@Column(name="TICKETNO")
	private Integer ticketNo;
	
	@Column(name="BOOKINGDATE")
	private Date bookingDate;
	
	@Column(name="CANCELLATIONDATE")
	private Date cancellationDate;
	
	@Column(name="JOURNEYDATE")
	private Date journeyDate;
	
	@Column(name="SEATNO")
	private Integer seatNo;
	
	@Column(name="TICKETSTATUS")
	private String ticketStatus;
	
	@Column(name="TRANSACTIONID")
	private Integer transactionId;
	
	@ManyToOne
	@JoinColumn(name="ROUTENO")
	private BusRoute routeNo;
	
	public Reservation() {
		super();
		System.out.println("Reservation is called");
	}

	public Integer getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(Integer ticketNo) {
		this.ticketNo = ticketNo;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Date getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public Integer getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(Integer seatNo) {
		this.seatNo = seatNo;
	}

	public String getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public BusRoute getRouteNo() {
		return routeNo;
	}

	public void setRouteNo(BusRoute routeNo) {
		this.routeNo = routeNo;
	}
	
}
