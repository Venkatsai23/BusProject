package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.Reservation;
import com.airbus.repos.ReservationRepository;



@SpringBootTest
class ReservationTest {

	@Autowired
    ReservationRepository resvRepo;
	
	@Test
	void resevationByTicketNo() {
		
		Reservation resv=resvRepo.findReservation(1);
	    System.out.println(resv.getBookingDate());
	    System.out.println(resv.getJourneyDate());
	    System.out.println(resv.getSeatNo());
	    System.out.println(resv.getTicketStatus());
	    System.out.println(resv.getTransactionId());
	    //System.out.println(resv.getRouteNo());
	}

}
